package VentanasDibujo.PanelesPaleta;

import javax.swing.*;

public class PanelDescripcion extends JPanel{

    private JTextPane descripcionPanelDescripcion;
    private JScrollPane jScrollPane1;
    private JLabel nombreHerramientaDescripcion;

    public PanelDescripcion(){

        iniciarComponentes();
    }

    private void iniciarComponentes(){

        nombreHerramientaDescripcion = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        descripcionPanelDescripcion = new javax.swing.JTextPane();


        nombreHerramientaDescripcion.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        nombreHerramientaDescripcion.setText("Descripción");

        descripcionPanelDescripcion.setEditable(false);
        jScrollPane1.setViewportView(descripcionPanelDescripcion);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(nombreHerramientaDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addContainerGap(47, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(nombreHerramientaDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(41, Short.MAX_VALUE))
        );
    }


    public void actualizarTexto(String tituloHerramienta, String descripcion) {
        this.nombreHerramientaDescripcion.setText(tituloHerramienta);
        this.descripcionPanelDescripcion.setText(descripcion);
    }
}
