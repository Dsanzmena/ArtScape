package VentanasDibujo.PanelesPaleta;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class PanelColores extends JPanel {
    private JTextField colorActualField;
    private JLabel colorActualLabel;
    private JTextField colorAnteriorField;
    private JLabel colorAnteriorLabel;
    private JTextPane descripcionPanelColor;
    private JScrollPane jScrollPane1;
    private JLabel nombreHerramientaColor;

    public PanelColores() {
        this.iniciarComponentes();
    }

    private void iniciarComponentes() {

        nombreHerramientaColor = new javax.swing.JLabel();
        colorAnteriorLabel = new javax.swing.JLabel();
        colorActualLabel = new javax.swing.JLabel();
        colorActualField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        descripcionPanelColor = new javax.swing.JTextPane();
        colorAnteriorField = new javax.swing.JTextField();

        nombreHerramientaColor.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        nombreHerramientaColor.setText("Lapiz");

        colorAnteriorLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        colorAnteriorLabel.setText("Color anterior:");

        colorActualLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        colorActualLabel.setText("Color actual:");

        colorActualField.setEditable(false);
        colorActualField.setPreferredSize(new java.awt.Dimension(32, 32));

        descripcionPanelColor.setEditable(false);
        jScrollPane1.setViewportView(descripcionPanelColor);

        colorAnteriorField.setEditable(false);
        colorAnteriorField.setPreferredSize(new java.awt.Dimension(32, 32));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(nombreHerramientaColor, javax.swing.GroupLayout.DEFAULT_SIZE, 312, Short.MAX_VALUE)
                                        .addComponent(jScrollPane1)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(colorAnteriorLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                                                        .addComponent(colorActualLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(colorActualField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(colorAnteriorField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addContainerGap(47, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(nombreHerramientaColor, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(colorActualLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(colorActualField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(colorAnteriorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(colorAnteriorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(39, Short.MAX_VALUE))
        );

    }

    public void actualizarTexto(String tituloHerramienta, String descripcion) {
        this.nombreHerramientaColor.setText(tituloHerramienta);
        this.descripcionPanelColor.setText(descripcion);
    }

    public void setColorAnterior(Color c) {
        this.colorAnteriorField.setBackground(c);
    }

    public void setColorPanel(Color c) {
        this.setBackground(c);
    }
}
