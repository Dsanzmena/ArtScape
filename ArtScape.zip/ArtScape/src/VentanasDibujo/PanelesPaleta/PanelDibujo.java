

package VentanasDibujo.PanelesPaleta;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class PanelDibujo extends JPanel {

    private JLabel colorDibujoLabel;
    private JTextField colorFieldDibujo;
    private JTextPane descripcionPanelDibujo;
    private JTextField grosorFieldDibujo;
    private JLabel grosorLabelDibujo;
    private JScrollPane jScrollPane1;
    private JLabel nombreHerramientaDibujo;

    public PanelDibujo() {
        this.iniciarComponentes();
    }

    private void iniciarComponentes() {

        nombreHerramientaDibujo = new javax.swing.JLabel();
        colorDibujoLabel = new javax.swing.JLabel();
        grosorFieldDibujo = new javax.swing.JTextField();
        grosorLabelDibujo = new javax.swing.JLabel();
        colorFieldDibujo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        descripcionPanelDibujo = new javax.swing.JTextPane();

        descripcionPanelDibujo.setText("Descripción: La herramienta Lápiz te permitirá \nrealizar dibujos libres manteniendo el click \nizquierdo del ratón.\n\nEn cualquier momento puedes cambiar el grosor \nde lapicero cambiando el valor del campo \ngrosor.\n\nDicho valor se debe encontrar entre 1 y 100.");
        nombreHerramientaDibujo.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        nombreHerramientaDibujo.setText("Lapiz");

        colorDibujoLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        colorDibujoLabel.setText("Color:");
        colorFieldDibujo.setBackground(Color.BLACK);

        grosorFieldDibujo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        grosorFieldDibujo.setText("1");
        grosorFieldDibujo.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                try {
                    int var2 = Integer.parseInt(grosorFieldDibujo.getText());
                } catch (NumberFormatException var3) {
                    this.error();
                }

            }

            public void removeUpdate(DocumentEvent e) {
            }

            public void changedUpdate(DocumentEvent e) {
            }

            private void error() {
                JOptionPane.showMessageDialog((Component)null, "Error: El valor " + grosorFieldDibujo.getText() + " no es válido", "Error", 0);
            }
        });

        grosorLabelDibujo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        grosorLabelDibujo.setText("Grosor:");

        colorFieldDibujo.setEditable(false);
        colorFieldDibujo.setPreferredSize(new java.awt.Dimension(32, 32));

        jScrollPane1.setViewportView(descripcionPanelDibujo);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(colorDibujoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(colorFieldDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(grosorLabelDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(grosorFieldDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(nombreHerramientaDibujo, javax.swing.GroupLayout.DEFAULT_SIZE, 312, Short.MAX_VALUE)
                                        .addComponent(jScrollPane1))
                                .addContainerGap(47, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(nombreHerramientaDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(grosorLabelDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(grosorFieldDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(colorDibujoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(colorFieldDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(43, Short.MAX_VALUE))
        );}

    public void actualizarTexto(String tituloHerramienta, String descripcion) {
        this.nombreHerramientaDibujo.setText(tituloHerramienta);
        this.descripcionPanelDibujo.setText(descripcion);
    }

    public int getGrosor() {
        int grosor = 0;

        try {
            grosor = Integer.parseInt(this.grosorFieldDibujo.getText());
            if (grosor <= 0 || grosor > 100) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException var3) {
            JOptionPane.showMessageDialog((Component)null, "Error: El valor " + this.grosorFieldDibujo.getText() + " no es válido", "Error", 0);
            this.grosorFieldDibujo.setText("1");
        }

        return grosor;
    }

    public void setColorPanel(Color c) {
        this.setBackground(c);
    }
}
