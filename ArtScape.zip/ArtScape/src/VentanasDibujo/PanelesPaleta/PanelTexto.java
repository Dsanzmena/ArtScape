package VentanasDibujo.PanelesPaleta;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


public class PanelTexto extends JPanel implements ItemListener {
    private JTextField colorFieldTexto;
    private JLabel colorLabelTexto;
    private JTextPane descripcionPanelTexto;
    private JComboBox<String> fuenteDesplegable;
    private JLabel fuenteLabel;
    private JScrollPane jScrollPane1;
    private JLabel nombreHerramientaTexto;
    private JLabel tamañoLabel;
    private JTextField tamañoTexto;
    private String fuente;



    public PanelTexto(){

        iniciarComponentes();
        fuente = "TimesRoman";
        fuenteDesplegable = new JComboBox<>();
    }

    private void iniciarComponentes() {

        nombreHerramientaTexto = new javax.swing.JLabel();
        fuenteLabel = new javax.swing.JLabel();
        tamañoTexto = new javax.swing.JTextField();
        tamañoLabel = new javax.swing.JLabel();
        colorFieldTexto = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        descripcionPanelTexto = new javax.swing.JTextPane();
        colorLabelTexto = new javax.swing.JLabel();
        fuenteDesplegable = new javax.swing.JComboBox<>();

        fuenteDesplegable.addItem("TimesRoman");
        fuenteDesplegable.addItem("Arial");
        fuenteDesplegable.addItem("Tahoma");
        fuenteDesplegable.addItem("Helvetica");
        fuenteDesplegable.addItem("Courier");
        fuenteDesplegable.addItem("ZapfDingbats");

        fuenteDesplegable.addItemListener(this);

        nombreHerramientaTexto.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        nombreHerramientaTexto.setText("Texto");

        fuenteLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fuenteLabel.setText("Fuente:");

        tamañoTexto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tamañoTexto.setText("1");
        tamañoTexto.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                try {
                    int var2 = Integer.parseInt(tamañoTexto.getText());
                } catch (NumberFormatException var3) {
                    this.error();
                }

            }

            public void removeUpdate(DocumentEvent e) {
            }

            public void changedUpdate(DocumentEvent e) {
            }

            private void error() {
                JOptionPane.showMessageDialog((Component)null, "Error: El valor " +tamañoTexto.getText() + " no es válido", "Error", 0);
            }
        });

        tamañoLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tamañoLabel.setText("Tamaño de texto:");

        colorFieldTexto.setEditable(false);
        colorFieldTexto.setBackground(new java.awt.Color(0, 0, 0));
        colorFieldTexto.setPreferredSize(new java.awt.Dimension(32, 32));

        descripcionPanelTexto.setEditable(false);
        jScrollPane1.setViewportView(descripcionPanelTexto);

        colorLabelTexto.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        colorLabelTexto.setText("Color:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(nombreHerramientaTexto, javax.swing.GroupLayout.DEFAULT_SIZE, 312, Short.MAX_VALUE)
                                        .addComponent(jScrollPane1)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(tamañoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(tamañoTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(colorLabelTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(fuenteLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(colorFieldTexto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(fuenteDesplegable, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addContainerGap(47, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(nombreHerramientaTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(tamañoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tamañoTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(colorLabelTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(colorFieldTexto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(fuenteLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(fuenteDesplegable, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(39, Short.MAX_VALUE))
        );
    }

    public void itemStateChanged(ItemEvent e) {

        if (e.getSource() == fuenteDesplegable) {
            fuente = (String) fuenteDesplegable.getSelectedItem();
        }
    }


    //GETTERS Y SETTERS
    public void actualizarTexto(String tituloHerramienta, String descripcion) {
        this.nombreHerramientaTexto.setText(tituloHerramienta);
        this.descripcionPanelTexto.setText(descripcion);
    }
    public int getTamañoTexto() {
        int valorTamañoTexto = 0;

        try {
            valorTamañoTexto = Integer.parseInt(tamañoTexto.getText());
            if (valorTamañoTexto <= 0 || valorTamañoTexto > 100) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException var3) {
            JOptionPane.showMessageDialog((Component)null, "Error: El valor " + tamañoTexto.getText() + " no es válido", "Error", 0);
            this.tamañoTexto.setText("1");
        }

        return valorTamañoTexto;
    }
    public void setColorPanel(Color c) {
        this.setBackground(c);
    }
    public String getFuente() {
        return this.fuente;
    }
}
