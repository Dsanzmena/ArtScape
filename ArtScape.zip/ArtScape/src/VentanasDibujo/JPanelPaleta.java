package VentanasDibujo;

import VentanasDibujo.PanelesPaleta.PanelColores;
import VentanasDibujo.PanelesPaleta.PanelDescripcion;
import VentanasDibujo.PanelesPaleta.PanelDibujo;
import VentanasDibujo.PanelesPaleta.PanelTexto;
import Decorator.Decorador;
import Singleton.Configuracion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;

public class JPanelPaleta  implements ActionListener{

    private Decorador decoracionPaleta;
    private Color colorFuente;
    private String herramienta;
    private ArrayList<JButton> botones;

    //PANELES
    private JPanel panelBotones;
    private JPanel panelOpciones;
    private JPanel panelDescripcion;
    private Color colorDibujo;

    //BOTONES HERRAMIENTAS
    private JButton botonLapiz;
    private JButton botonGoma;
    private JButton botonTexto;
    private JButton botonLinea;
    private JButton botonRectangulo;
    private JButton botonCuadrado;
    private JButton botonCirculo;
    private JButton botonElipse;
    private JButton botonCuentagotas;
    private JButton botonCubo;
    private JButton botonSeleccion;
    private JButton botonLupa;


    //BOTONES OPCIONES
    private JButton botonColores;
    private JButton botonAtras;
    private JButton botonAdelante;

    //MENU HERRAMIENTA

        //JPANEL CARD PARA LAPIZ, GOMA, LINEA, CUADRADO, RECTANGULO, CIRCULO Y ELIPSE
        private PanelDibujo cardDibujo;

        //JPANEL CARD PARA TEXTO
        private PanelTexto cardTexto;

        //JPANEL CARD PARA CUENTAGOTAS Y CUBO
        private PanelColores cardColores;

        //JPANEL CARD PARA SELECTOR COLOR, AVANCE Y RETROCESO
        private PanelDescripcion cardDescripcion;


    public JPanelPaleta(Color dibujo){
        panelBotones = new JPanel();
        panelOpciones = new JPanel();
        panelDescripcion = new JPanel(new CardLayout());
        botones = new ArrayList<JButton>();
        colorDibujo = Color.BLACK;

        inicializarBotones();
    }

    //MÉTODOS OBSERVER BEAN
    private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    public void añadirObserver(PropertyChangeListener pcl){
        this.pcs.addPropertyChangeListener(pcl);
    }

    //INICIALIZAR BOTONES
    private void inicializarBotones() {

        //HERRAMIENTAS DIBUJO
        botonLapiz = new JButton(new ImageIcon("src\\recursos\\lapiz.png"));
        panelBotones.add(botonLapiz);
        botones.add(botonLapiz);

        botonGoma = new JButton(new ImageIcon("src\\recursos\\goma.png"));
        panelBotones.add(botonGoma);
        botones.add(botonGoma);

        botonTexto = new JButton(new ImageIcon("src\\recursos\\texto.png"));
        panelBotones.add(botonTexto);
        botones.add(botonTexto);

        botonLinea = new JButton(new ImageIcon("src\\recursos\\linea.png"));
        panelBotones.add(botonLinea);
        botones.add(botonLinea);

        botonRectangulo = new JButton(new ImageIcon("src\\recursos\\rectangulo.png"));
        panelBotones.add(botonRectangulo);
        botones.add(botonRectangulo);

        botonCuadrado = new JButton(new ImageIcon("src\\recursos\\cuadrado.png"));
        panelBotones.add(botonCuadrado);
        botones.add(botonCuadrado);

        botonCirculo = new JButton(new ImageIcon("src\\recursos\\circulo.png"));
        panelBotones.add(botonCirculo);
        botones.add(botonCirculo);

        botonElipse = new JButton(new ImageIcon("src\\recursos\\elipse.png"));
        panelBotones.add(botonElipse);
        botones.add(botonElipse);

        botonCuentagotas = new JButton(new ImageIcon("src\\recursos\\cuentagotas.png"));
        panelBotones.add(botonCuentagotas);
        botones.add(botonCuentagotas);

        panelBotones.add(new JLabel(""));
        botonCubo = new JButton(new ImageIcon("src\\recursos\\cubo.png"));
        panelBotones.add(botonCubo);
        botones.add(botonCubo);

        panelBotones.setLayout(new GridLayout(4,3,10,10));

        //BOTONES OPCIONES

        botonColores = new JButton(new ImageIcon("src\\recursos\\color.png"));
        panelOpciones.add(botonColores);
        botones.add(botonColores);

        botonAtras = new JButton(new ImageIcon("src\\recursos\\atras.png"));
        panelOpciones.add(botonAtras);
        botones.add(botonAtras);

        botonAdelante = new JButton(new ImageIcon("src\\recursos\\adelante.png"));
        panelOpciones.add(botonAdelante);
        botones.add(botonAdelante);

        panelOpciones.setLayout(new GridLayout(1,3,10,10));


        //PANEL PARA LAPIZ, GOMA, LINEA, CUADRADO, RECTANGULO, CIRCULO Y ELIPSE
        cardDibujo = new PanelDibujo();
        panelDescripcion.add(cardDibujo,"DIBUJO");

        //PANEL TEXTO
        cardTexto = new PanelTexto();
        panelDescripcion.add(cardTexto,"TEXTO");

        //PANEL CUENTAGOTAS Y CUBO
        cardColores = new PanelColores();
        panelDescripcion.add(cardColores,"COLORES");

        //PANEL SELECTOR DE COLORES, AVANCE Y RETROCESO
        cardDescripcion = new PanelDescripcion();
        panelDescripcion.add(cardDescripcion,"DESCRIPCION");

        //Añadimos a cada boton un listener
        for(JButton b: botones){
            b.addActionListener(this);
        }


    }

    public void cambioPanel(String nombrePanel) {
        CardLayout cl = (CardLayout)(panelDescripcion.getLayout());
        cl.show(panelDescripcion, nombrePanel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int numOp = 1;

        for(JButton boton: botones){

            JButton b =  (JButton) e.getSource();
            boton.setBackground(Configuracion.COLOR_FONDO);

            if (b.equals(boton)) {

                System.out.println();
                boton.setBackground(Color.green);
                PropertyChangeEvent pce = new PropertyChangeEvent(this, "HERRAMIENTA", null, numOp);
                pcs.firePropertyChange(pce);

                switch (numOp){

                    case 1:
                        cambioPanel("DIBUJO");
                        cardDibujo.actualizarTexto("Lápiz","Descripción: La herramienta Lápiz te permitirá \nrealizar dibujos libres manteniendo el click \nizquierdo del ratón.\n\nEn cualquier momento puedes cambiar el grosor \nde lapicero cambiando el valor del campo \ngrosor.\n\nDicho valor se debe encontrar entre 1 y 100.");
                        break;
                    case 2:
                        cambioPanel("DIBUJO");
                        cardDibujo.actualizarTexto("Goma","Descripción: La herramienta goma te permitirá \nborrar cualquier forma de manera libre \nmanteniendo el click izquierdo del ratón.\n\nEn cualquier momento puedes cambiar el grosor\nde la goma cambiando el valor del campo grosor. \n\nDicho valor se debe encontrar entre 1 y 100.");
                        break;
                    case 4:
                        cambioPanel("DIBUJO");
                        cardDibujo.actualizarTexto("Línea","Descripción: La herramienta línea te permitirá \ncrear una línea manteniendo el click izquierdo y\nsoltandolo para definir el final de dicha línea.\n\nEn cualquier momento puedes cambiar el grosor\nde la goma cambiando el valor del campo grosor. \n\nDicho valor se debe encontrar entre 1 y 100.");
                        break;
                    case 5:
                        cambioPanel("DIBUJO");
                        cardDibujo.actualizarTexto("Rectángulo","Descripción: La herramienta rectángulo te \npermitirá crear una rectangulo manteniendo el\nclick izquierdo y soltandolo para definir el \ntamaño del rectángulo.\n\nEn cualquier momento puedes cambiar el grosor\nde la goma cambiando el valor del campo grosor. \n\nDicho valor se debe encontrar entre 1 y 100.");
                        break;
                    case 6:
                        cambioPanel("DIBUJO");
                        cardDibujo.actualizarTexto("Cuadrado","Descripción: La herramienta cuadrado te \npermitirá crear un cuadrado manteniendo el\nclick izquierdo y soltandolo para definir el \ntamaño del cuadrado.\n\nEn cualquier momento puedes cambiar el grosor\nde la goma cambiando el valor del campo grosor. \n\nDicho valor se debe encontrar entre 1 y 100.");
                        break;
                    case 7:
                        cambioPanel("DIBUJO");
                        cardDibujo.actualizarTexto("Círculo","Descripción: La herramienta círculo te \npermitirá crear un círculo manteniendo el\nclick izquierdo y soltandolo para definir el \ntamaño del círculo.\n\nEn cualquier momento puedes cambiar el grosor\nde la goma cambiando el valor del campo grosor. \n\nDicho valor se debe encontrar entre 1 y 100.");
                        break;
                    case 8:
                        cambioPanel("DIBUJO");
                        cardDibujo.actualizarTexto("Elipse","Descripción: La herramienta elipse te \npermitirá crear una elipse manteniendo el\nclick izquierdo y soltandolo para definir el \ntamaño del elipse.\n\nEn cualquier momento puedes cambiar el grosor\nde la goma cambiando el valor del campo grosor. \n\nDicho valor se debe encontrar entre 1 y 100.");
                        break;
                    case 3:
                        cambioPanel("TEXTO");
                        cardTexto.actualizarTexto("Texto","Descripción: La herramienta texto te permitira\nescribir cualquier texto. Puedes cambiar el \ntamaño y la fuente de este texto.\n\nPara terminar de escribir puedes apretar la \ntecla Esc o simplemente seleccionar otra \nherramienta.\n\nDicho valor se debe encontrar entre 1 y 100.");
                        break;
                    case 9:
                        cambioPanel("COLOR");
                        cardDibujo.actualizarTexto("Cuentagotas","Descripción: La herramienta cuentagotas te \npermitirá obtener el color de una la zona \nclickeada con el botón izquierdo del ratón.\n\nDe esta manera el color de dibujo se cambiará\npor el que hayas dibujado.");
                        break;
                    case 10:
                        cambioPanel("COLOR");
                        cardDibujo.actualizarTexto("Cubo","Descripción: La herramienta cubo te permitirá \nrellenar una figura cualquiera delimitada.\nDe esta manera la figura quedara rellenada por\nel color que esté seleccionado.");
                        break;
                    case 11:
                        cambioPanel("DESCRIPCION");
                        cardDescripcion.actualizarTexto("Selector de color","Descripción: La herramienta selector de color\nte permite seleccionar un color cualquiera de \nuna paleta desplegable.");
                        break;
                    case 12:
                        cambioPanel("DESCRIPCION");
                        cardDescripcion.actualizarTexto("Retroceso","Descripción: El boton retroceso permite volver\na un dibujo anterior al realizado.");
                        break;
                    case 13:
                        cambioPanel("DESCRIPCION");
                        cardDescripcion.actualizarTexto("Avance","Descripción: El boton avance permite avanzar \nhasta el último dibujo realizado.");
                        break;
                }
            }

            numOp++;
        }
    }


    //GETTERS Y SETTERS
    public void setColorPanel(Color c){

        this.panelBotones.setBackground(c);
        this.panelDescripcion.setBackground(c);
        this.panelOpciones.setBackground(c);
        cardColores.setBackground(c);
        cardDescripcion.setBackground(c);
        cardDibujo.setBackground(c);
        cardTexto.setBackground(c);

        for(int i= 0 ;i < panelBotones.getComponentCount(); i++){
            this.panelBotones.getComponent(i).setBackground(c);
        }

        for(int i= 0 ;i < panelOpciones.getComponentCount(); i++){
            this.panelDescripcion.getComponent(i).setBackground(c);
        }

    }
    public void setColorDibujo(Color c){
        this.colorDibujo = c;
        cardColores.setColorAnterior(c);
    }
    public JPanel getPanelBotones(){
        return panelBotones;
    }
    public JPanel getPanelOpciones(){
        return panelOpciones;
    }
    public JPanel getPanelDescripcion(){
        return panelDescripcion;
    }
    public int getGrosor(){
        return cardDibujo.getGrosor();
    }
    public int getTamañoTexto(){
        return cardTexto.getTamañoTexto();
    }
    public String getFuente(){
        return cardTexto.getFuente();
    }
}
