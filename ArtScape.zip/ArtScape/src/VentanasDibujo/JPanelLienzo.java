package VentanasDibujo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import javax.swing.*;


public class JPanelLienzo implements ActionListener {
    //BARRA MENU
    private JMenuBar barraMenu;
    private JTextField textField;
    private JPanel panel;

    //ARCHIVO
    private JMenu archivo;
        private JMenuItem abrir;
        private JMenuItem guardarComo;
        private JMenuItem salir;

    //VISTA
    private JMenu vista;
        private ButtonGroup grupoBotonesColor;
        private JRadioButtonMenuItem  modoOscuro;
        private JRadioButtonMenuItem  modoClaro;

        private JSeparator separador;

        private ButtonGroup grupoBotonesPos;
        private JRadioButtonMenuItem  lateralIzq;
        private JRadioButtonMenuItem  lateralDrc;

    //USUARIO
    private JMenu usuario;
        private JMenuItem miPerfil;
        private JMenuItem cerrarSesion;



    //CONSTRUCTOR
    public JPanelLienzo(JPanel panel){
        this.panel = panel;
        inicializaBarraMenu();

    }

    //MÉTODOS OBSERVER BEAN
    private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    public void añadirObserver(PropertyChangeListener pcl){
        this.pcs.addPropertyChangeListener(pcl);
    }


    //INICIALIZA JPANEL Y JMENU: Contiene también el método paintComponent que dibuja las figuras
    private void inicializaBarraMenu(){

        barraMenu = new JMenuBar();

        archivo = new JMenu("Archivo") ;
        abrir = new JMenuItem("Abrir");
        guardarComo = new JMenuItem("Guardar como...");
        salir = new JMenuItem("Salir");

        vista  = new JMenu("Vista") ;
        grupoBotonesColor = new ButtonGroup();
        modoOscuro = new JRadioButtonMenuItem("Modo oscuro");
        modoClaro = new JRadioButtonMenuItem("Modo claro",true);

        separador = new JSeparator();

        grupoBotonesPos = new ButtonGroup();
        lateralIzq = new JRadioButtonMenuItem("Lateral izquierdo",true);
        lateralDrc = new JRadioButtonMenuItem("Lateral derecho");

        usuario = new JMenu("Estate");
        miPerfil = new JMenuItem("Mi perfil");
        cerrarSesion = new JMenuItem("Cerrar sesión");

        archivo.add(abrir);
        archivo.add(guardarComo);
        archivo.add(salir);

        guardarComo.addActionListener(this);
        abrir.addActionListener(this);
        salir.addActionListener(this);

        grupoBotonesColor.add(modoOscuro);
        grupoBotonesColor.add(modoClaro);

        modoOscuro.addActionListener(this);
        modoClaro.addActionListener(this);

        vista.add(modoOscuro);
        vista.add(modoClaro);
        vista.add(separador);

        grupoBotonesPos.add(lateralIzq);
        grupoBotonesPos.add(lateralDrc);

        lateralIzq.addActionListener(this);
        lateralDrc.addActionListener(this);

        vista.add(lateralIzq);
        vista.add(lateralDrc);

        usuario.add(miPerfil);
        usuario.add(cerrarSesion);

        miPerfil.addActionListener(this);
        cerrarSesion.addActionListener(this);

        barraMenu.add(archivo);
        barraMenu.add(vista);
        barraMenu.add(usuario);

        panel.setBackground(Color.GRAY);

    }

    //LISTENERS DE LOS BOTONES DE JPANEL
    @Override
    public void actionPerformed(ActionEvent e) {
        PropertyChangeEvent pce;
        String texto;

        JMenuItem boton = (JMenuItem) e.getSource();
        texto = boton.getText();

        pce = new PropertyChangeEvent( this, "BOTONMENU" , null, texto);
        pcs.firePropertyChange(pce);

    }


    //GETTERS Y SETTER
    public JPanel getPanel(){
        return panel;
    }
    public JMenuBar getMenu(){
        return barraMenu;
    }



}
