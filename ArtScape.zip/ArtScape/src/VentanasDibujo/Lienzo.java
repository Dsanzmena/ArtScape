package VentanasDibujo;

import Command.ComandoCambiarImagen;
import Decorator.Decorador;
import Facade.Controles.FachadaControles;
import Facade.Controles.Posicion;
import FactoryMethod.FactoriaFiguras;
import FactoryMethod.Figura;
import FactoryMethod.FigurasTemplateMethod.*;
import FactoryMethod.GestorFiguras.ColeccionFiguras;
import FactoryMethod.GestorFiguras.HiloEscritor;
import FactoryMethod.GestorFiguras.HiloLector;
import FactoryMethod.GestorFiguras.Imagen;
import Singleton.Configuracion;


import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Stack;


public class Lienzo extends JFrame{

    //ATRIBUTOS
    private Configuracion configuracion;
    private Decorador decoracionLienzo;
    private String herramienta;
    private JPanel panelDibujo;


    //CREACION FIGURAS
    private FactoriaFiguras factoria;
    private ColeccionFiguras coleccionFiguras;
    private ArrayList<Figura> figuras;
    private HiloEscritor escritor;
    private HiloLector lector;

    private BufferedImage imagenActual;

    private ArrayList<Imagen> imagenesCubo;


    //LIENZO Y CONTROLES
    private FachadaControles fachadaControles;
    private JPanelLienzo panel;
    public Color colorDibujo;
    private int nFigurasTotal;
    private int contadorFiguras;

    //COMMAND
    private ComandoCambiarImagen comandoCambiarImagen;

    //CONSTRUCTOR
    public Lienzo(Decorador decoracionLienzo, String herramienta, FachadaControles fachadaControles) {

        //VENTANA
        this.setTitle("Lienzo");
        ImageIcon imagenIcono=new ImageIcon("src\\recursos\\iconArtScape.png");
        setIconImage(imagenIcono.getImage());

        //ATRIBUTOS
        this.configuracion = configuracion;
        this.herramienta = herramienta;
        this.factoria = new FactoriaFiguras();
        this.fachadaControles = fachadaControles;
        this.decoracionLienzo = decoracionLienzo;

        //COLECCION FIGURAS
        this.coleccionFiguras = new ColeccionFiguras();
        this.escritor = new HiloEscritor(coleccionFiguras);
        this.lector = new HiloLector(coleccionFiguras);

        this.imagenesCubo = new ArrayList<>();

        //JPANEL
        this.figuras = new ArrayList<Figura>();

        this.colorDibujo = Color.BLACK;

        class PanelDibujo extends JPanel{

            public void paintComponent(Graphics g){
                super.paintComponent(g);
                dibujar(g);
            }
        }
        panelDibujo = new PanelDibujo();
        this.panel = new JPanelLienzo(panelDibujo);
        this.panel.getPanel().setBackground(Color.WHITE);
        this.setJMenuBar(panel.getMenu());
        this.getContentPane().add(panel.getPanel());

        //COMMAND Y MEMENTO
        comandoCambiarImagen = new ComandoCambiarImagen();

        this.nFigurasTotal = 0;
        this.contadorFiguras =0;

    }


    //FUNCIONES DE DIBUJO
    private void dibujar(Graphics g){

        figuras = (ArrayList<Figura>) lector.leer();
        Graphics2D grafico = (Graphics2D) g;

        grafico.setStroke(new BasicStroke((float) 1));

        //BORRAR CUANDO FINALICEMOS
        if(fachadaControles.getRaton().getMoved() != null){
            grafico.drawString(fachadaControles.getRaton().getMoved().toString(), 20, 20);
        }

            for(int i=0; i<nFigurasTotal; i++){

                imagenActual= comandoCambiarImagen.getImagen();
                if(imagenActual!=null){
                    grafico.drawImage(imagenActual,0,0,imagenActual.getWidth(),imagenActual.getHeight(),null);
                }

                for(Imagen img: imagenesCubo){
                    if(img.prioridad == i){
                        BufferedImage bi = img.imagen;
                        grafico.drawImage( bi ,0,0, bi .getWidth(), bi .getHeight(),null);
                    }
                }

                for(Figura f: figuras){
                    if(f.prioridad == i){

                        if(f instanceof DibujoLibre){
                            DibujoLibre figura = (DibujoLibre) f;
                            grafico.setColor(figura.color);
                            grafico.setStroke(new BasicStroke((long) figura.grosor));

                            if(!figura.lineas.isEmpty()){

                                for(Linea linea: figura.lineas){
                                    grafico.drawLine(linea.pCx,linea.pCy,linea.pRx, linea.pRy);
                                }
                            }
                        }

                        else if(f instanceof Goma){
                            Goma figura = (Goma) f;
                            grafico.setColor(figura.color);
                            grafico.setStroke(new BasicStroke((long) figura.grosor));
                            if(!figura.lineas.isEmpty()){

                                for(Linea linea: figura.lineas){
                                    grafico.drawLine(linea.pCx,linea.pCy,linea.pRx, linea.pRy);
                                }
                            }
                        }

                        else if (f instanceof Texto){
                            Texto figura = (Texto) f;
                            grafico.setColor(figura.color);
                            //System.out.println("Fuente "+ figura.fuente+" tamaño "+figura.grosor);

                            grafico.drawChars(figura.texto,0,figura.texto.length,figura.x, figura.y);
                            if(!figura.textoTerminado){
                                figura.actualizar();
                            }
                        }

                        else if (f instanceof Rectangulo){
                            Rectangulo figura = (Rectangulo) f;
                            grafico.setStroke(new BasicStroke((long) figura.grosor));
                            grafico.setColor(figura.color);
                            grafico.drawRect(figura.x,figura.y,figura.ancho,figura.alto);

                        }else if(f instanceof Cuadrado){
                            Cuadrado figura = (Cuadrado) f;
                            grafico.setStroke(new BasicStroke((long) figura.grosor));
                            grafico.setColor(figura.color);
                            grafico.drawRect(figura.x,figura.y,figura.ancho,figura.alto);

                        }else if(f instanceof Circulo){
                            Circulo figura = (Circulo) f;
                            grafico.setStroke(new BasicStroke((long) figura.grosor));
                            grafico.setColor(figura.color);
                            grafico.drawOval(figura.x,figura.y,figura.ancho,figura.alto);

                        }else if(f instanceof Elipse){
                            Elipse figura = (Elipse) f;
                            grafico.setStroke(new BasicStroke((long) figura.grosor));
                            grafico.setColor(figura.color);
                            grafico.drawOval(figura.x,figura.y,figura.ancho,figura.alto);

                        }else if(f instanceof Linea){
                            Linea figura = (Linea) f;
                            grafico.setStroke(new BasicStroke((long) figura.grosor));
                            grafico.setColor(figura.color);
                            grafico.drawLine(figura.pCx,figura.pCy,figura.pRx, figura.pRy);
                        }
                    }
                }
            }



    }
    public Figura añadirDibujo(Posicion click, Posicion released, int grosor, String fuente){

        Figura f= factoria.getFigura(herramienta, click, released, colorDibujo, grosor, fuente);
        f.prioridad = nFigurasTotal;
        escritor.escribir(f);

        añadirImagen(guardarImagen());
        return f;
    }
    public Linea añadirLineas(Posicion posMov1, Posicion posMov2, Color color, int grosor){

        Linea l = (Linea) factoria.getFigura("LINEA", posMov1 , posMov2, color, grosor,"");
        return l;
    }
    public void pintarCubo(Posicion click){

        BufferedImage img = new BufferedImage(this.getContentPane().getWidth(),this.getContentPane().getHeight(),BufferedImage.TYPE_INT_RGB);
        Graphics2D grafico = img.createGraphics();
        this.getContentPane().printAll(grafico);
        grafico.dispose();

        Color color = new Color(img.getRGB(click.getX(), click.getY()));
        img = algoritmoRellenado(click.getX(), click.getY(), img, colorDibujo);

        imagenesCubo.add(new Imagen(img,nFigurasTotal));
        añadirImagen(img);


    }

    //OPCIONES MENU
    public BufferedImage guardarImagen(){

        BufferedImage img = new BufferedImage(this.getContentPane().getWidth(),this.getContentPane().getHeight(),BufferedImage.TYPE_INT_RGB);
        Graphics2D grafico = img.createGraphics();
        this.getContentPane().printAll(grafico);
        grafico.dispose();

        return img;
    }
    public Color obtenerColorCuentagotas(Posicion click){

        BufferedImage img = new BufferedImage(this.getContentPane().getWidth(),this.getContentPane().getHeight(),BufferedImage.TYPE_INT_RGB);
        Graphics2D grafico = img.createGraphics();
        this.getContentPane().printAll(grafico);
        grafico.dispose();

        Color color = new Color(img.getRGB(click.getX(),click.getY()));
        setColorDibujo(color);

        return color;
    }

    //MEMENTO Y COMMAND
    public void añadirImagen(BufferedImage img){
        comandoCambiarImagen.añadirImagen(guardarImagen(),nFigurasTotal);
        contadorFiguras++;
        nFigurasTotal++;
    }
    public void cogerImagenAnterior(){

        if(nFigurasTotal>1){

            nFigurasTotal--;
            comandoCambiarImagen.deshacer(nFigurasTotal);
        }else{
            JOptionPane.showMessageDialog((Component)null, "Error: No hay dibujos anteriores a este ", "Error", 0);
        }
    }
    public void cogerImagenPosterior(){

        if(contadorFiguras!=nFigurasTotal){

            nFigurasTotal++;
            comandoCambiarImagen.rehacer(nFigurasTotal);
        }else{
            JOptionPane.showMessageDialog((Component)null, "Error: No hay dibujos siguientes a este ", "Error", 0);
        }
    }

    //ALGORITMO RELLENADO CUBO
    public boolean coordenadaValida(int x, int y, int marcoX, int marcoY){

        if (x < 0 || y < 0) {
            return false;
        }
        if (x > marcoX || y > marcoY) {
            return false;
        }
        return true;

    }
    public BufferedImage algoritmoRellenado(int x, int y , BufferedImage area, Color colorCubo){

        //Array de posiciones ya visitadas
        int marcoX = 1334-2;
        int marcoY = 838-9;
        int vistados[][] = new int[marcoX][marcoY];

        for (int i = 0; i < marcoX; i++) {
            for (int j = 0; j < marcoY; j++) {
                vistados[i][j] = 0;
            }
        }

        //Creamos stack
        Stack <Posicion> stack = new Stack<Posicion>();

        //Posicion
        Posicion posicion = new Posicion(x,y);
        stack.push(posicion);

        //Indicamos que x e y estan visitados
        vistados[x][y] = 1;

        //Obtenemos el color que ha clickeado el usuario
        Color colorClickeado = new Color(area.getRGB(x,y));

        boolean condicion = true;

        while (!stack.empty()){

            Posicion pos = stack.pop();
            int posX = pos.getX();
            int posY = pos.getY();

            area.setRGB(posX,posY,colorCubo.getRGB());

            //Si el color clickeado es igual al siguiente pixel derecho && no esta visitado && esta dentro de la pantalla
            if((coordenadaValida(posX+1, posY, marcoX, marcoY)) && (colorClickeado.equals(new Color(area.getRGB(posX+1,posY)))) && (vistados[posX+1][posY] == 0)) {   //DERECHA

                Posicion nuevo = new Posicion(posX+1, posY);
                stack.push(nuevo);
                vistados[posX + 1][posY] = 1;

            }if((coordenadaValida(posX-1, posY, marcoX, marcoY)) && (colorClickeado.equals(new Color(area.getRGB(posX-1,posY)))) && (vistados[posX-1][posY] == 0)){   //IZQUIERDA

                Posicion nuevo = new Posicion(posX-1,posY);
                stack.push(nuevo);
                vistados[posX-1][posY] = 1;

           }if((coordenadaValida(posX, posY+1, marcoX, marcoY)) && (colorClickeado.equals(new Color(area.getRGB(posX,posY+1)))) && (vistados[posX][posY+1] == 0)){   //BAJAR

                Posicion nuevo = new Posicion(posX,posY+1);
                stack.push(nuevo);
                vistados[posX][posY+1] = 1;

           }if((coordenadaValida(posX, posY-1, marcoX, marcoY)) && (colorClickeado.equals(new Color(area.getRGB(posX,posY-1)))) && (vistados[posX][posY-1] == 0)){   //SUBIR

                Posicion nuevo = new Posicion(posX,posY-1);
                stack.push(nuevo);
                vistados[posX][posY-1] = 1;

           }

        }

        return area;

    }

    //GETTERS Y SETTERS
    public void setHerramienta(String herramienta){
        this.herramienta = herramienta;
    }
    public JPanelLienzo getPanelLienzo(){
        return this.panel;
    }
    public void setColorDibujo(Color c){
        this.colorDibujo = c;
    }
    public Color getColorSeleccionado(){
        return colorDibujo;
    }





}
