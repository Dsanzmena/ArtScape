package VentanasDibujo;

import Decorator.Decorador;

import javax.swing.*;
import java.awt.*;


public class Paleta extends JFrame{

    private Decorador decoracionPaleta;
    private JPanelPaleta panel;
    private Color colorDibujo;

    //CONSTRUCTOR
    public Paleta(Decorador decoracionPaleta, String herramienta){

        this.decoracionPaleta = decoracionPaleta;
        this.colorDibujo = Color.BLACK;
        this.panel = new JPanelPaleta(colorDibujo);
        JSeparator separador = new JSeparator(SwingConstants.HORIZONTAL);
        JSeparator separador1 = new JSeparator(SwingConstants.HORIZONTAL);
        Dimension d = new Dimension(300,2);
        separador.setPreferredSize(d);
        separador1.setPreferredSize(d);
        this.getContentPane().setLayout(new FlowLayout (FlowLayout.CENTER,0,25));
        this.getContentPane().add(panel.getPanelBotones());
        this.getContentPane().add(separador);
        this.getContentPane().add(panel.getPanelOpciones());
        this.getContentPane().add(separador1);
        this.getContentPane().add(panel.getPanelDescripcion());

        this.setTitle("Paleta");
        ImageIcon imagenIcono=new ImageIcon("src\\recursos\\iconArtScape.png");
        setIconImage(imagenIcono.getImage());

    }

    public void actualizarVentana(String posicion, String modo){
        decoracionPaleta.setPosicionPaleta(posicion);
        decoracionPaleta.setModo(modo);
    }

    public JPanelPaleta getPanelPaleta(){
        return panel;
    }
    public void setColorPanel(Color c){
        this.panel.setColorPanel(c);
        this.getContentPane().setBackground(c);
    }
    public void setColorDibujo(Color c){
        this.colorDibujo = c;
        this.panel.setColorDibujo(c);
    }

}
