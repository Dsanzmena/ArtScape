package Command;

import java.awt.image.BufferedImage;

public interface Comando {

    public BufferedImage getImagen();
    public void setImagen(BufferedImage image);

}
