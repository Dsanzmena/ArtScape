package Command;

public interface ComandoDeshacer extends Comando {

    public abstract void deshacer(int prioridad);
    public abstract void rehacer(int prioridad);
}
