package Command;

import java.awt.image.BufferedImage;

public class Invocador implements ComandoDeshacer{


    private ComandoDeshacer comando;


    @Override
    public BufferedImage getImagen(){
        return comando.getImagen();
    }

    @Override
    public void setImagen(BufferedImage image) {
        comando.setImagen(image);
    }

    @Override
    public void deshacer(int prioridad) {
        comando.deshacer(prioridad);
    }

    @Override
    public void rehacer(int prioridad) {
        comando.rehacer(prioridad);
    }
}
