package Command;

import Memento.ColectorImagenesConserje;
import Memento.Originador;

import java.awt.image.BufferedImage;

public class ComandoCambiarImagen implements ComandoDeshacer{


    public ColectorImagenesConserje conserje = new ColectorImagenesConserje();
    private Originador originador = new Originador();


    @Override
    public BufferedImage getImagen() {
        return originador.getImagenActual();
    }

    @Override
    public void setImagen(BufferedImage image) {
        originador.setImagenActual(image);
    }

    public void añadirImagen(BufferedImage image, int prioridad){
        conserje.guardarRecuerdo(originador.crearRecuerdo(image,prioridad));
        setImagen(image);
    }

    @Override
    public void deshacer(int prioridad) {

        try{
            originador.setImagenActual(conserje.getRecuerdo(prioridad).getImagen());
        }catch (Exception e){

        }

    }

    @Override
    public void rehacer(int prioridad) {
        try{
            originador.setImagenActual(conserje.getRecuerdo(prioridad).getImagen());
        }catch (Exception e){

        }


    }
}
