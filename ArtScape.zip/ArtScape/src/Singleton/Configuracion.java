package Singleton;
import Decorator.Decoracion;

import java.awt.*;

public class Configuracion implements Decoracion {

    //CONFIGURACION PALETA
    public static int ANCHO_PALETA;
    public static int ALTO_PALETA;
    public static Color COLOR_FONDO;
    public static String POSICION_PALETA;

    //CONFIGURACION LIENZO
    public static int ANCHO_LIENZO;
    public static int ALTO_LIENZO;

    //CONFIGURACIÓN GENERAL
    public static Color COLOR_FUENTE;


    public Configuracion() {

    }


    public void setTamaño(int alto, int ancho) {

    }

    @Override
    public void setColorFondo(Color c) {
        COLOR_FONDO = c;
    }

    @Override
    public void setColorFuente(Color c) {

    }

    public void setModo(String modo){

        if(modo=="CLARO"){
            COLOR_FONDO = new Color(230,255,230);
            COLOR_FUENTE = Color.BLACK;

        }else if (modo=="OSCURO"){
            COLOR_FONDO = new Color(94, 102, 109);
            COLOR_FUENTE = Color.WHITE;
        }
    }

}