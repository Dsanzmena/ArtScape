package FactoryMethod.GestorFiguras;

import FactoryMethod.Figura;
import java.util.ArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ColeccionFiguras {

    private ArrayList<Figura> figuras = new ArrayList<>();

    private Lock candado = new ReentrantLock();

    public Object leer(){

        candado.lock();
        Object obj = new Object();
        try{

            obj = figuras;

        }catch(Exception e){}
        finally{

            candado.unlock();
            return obj;
        }

    }


    public void agregar(Object obj){

        candado.lock();

        try{

            figuras.add((Figura) obj);

        }catch(Exception e){}
        finally{

            candado.unlock();
        }
    }
}
