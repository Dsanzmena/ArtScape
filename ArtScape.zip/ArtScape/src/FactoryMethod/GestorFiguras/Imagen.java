package FactoryMethod.GestorFiguras;

import java.awt.image.BufferedImage;

public class Imagen {

    public BufferedImage imagen;
    public int prioridad;

    public Imagen(BufferedImage imagen, int p){
        this.imagen = imagen;
        this.prioridad = p;
    }
}
