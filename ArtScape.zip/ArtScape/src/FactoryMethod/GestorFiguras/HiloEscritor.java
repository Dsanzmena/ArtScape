package FactoryMethod.GestorFiguras;

public class HiloEscritor extends Thread{

    private ColeccionFiguras figuras;

    public HiloEscritor(ColeccionFiguras cf){
        this.figuras= cf;
    }

    public void run(){

    }

    public void escribir(Object obj){

        figuras.agregar(obj);
    }
}
