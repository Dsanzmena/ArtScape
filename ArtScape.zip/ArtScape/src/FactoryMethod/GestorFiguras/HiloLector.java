package FactoryMethod.GestorFiguras;

public class HiloLector extends Thread{

    private ColeccionFiguras figuras;

    public HiloLector(ColeccionFiguras cf ){
        this.figuras= cf;
    }

    public void run(){

    }

    public Object leer(){

        Object o = figuras.leer();
        return o ;
    }
}
