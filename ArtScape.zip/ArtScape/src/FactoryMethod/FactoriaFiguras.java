package FactoryMethod;

import Facade.Controles.Posicion;
import FactoryMethod.FigurasTemplateMethod.*;

import java.awt.*;

public class FactoriaFiguras {

    public FactoriaFiguras(){

    }

    public Figura getFigura(String tipo, Posicion posClick, Posicion posReleased, Color color, int grosor, String fuente){

        switch(tipo){

            case "DIBUJO LIBRE":
               return(new DibujoLibre(color, grosor));

            case "GOMA":
                return(new Goma(Color.WHITE, grosor));

            case "TEXTO":
                return(new Texto(posClick ,color, grosor,fuente));

            case "LINEA":
                return(new Linea(posClick, posReleased, color, grosor));

            case "CUADRADO":
                return(new Cuadrado(posClick, posReleased, color, grosor));

            case "RECTANGULO":
                return(new Rectangulo(posClick, posReleased, color, grosor));

            case "CIRCULO":
                return(new Circulo(posClick, posReleased, color, grosor));

            case "ELIPSE":
                return(new Elipse(posClick, posReleased, color, grosor));

            default:
                //Sentencia que nunca se ejecuta
                return null;

        }


    }
}
