package FactoryMethod;

import java.awt.*;
import java.awt.geom.Point2D;

public abstract class Figura {

    public Color color;
    public int grosor;
    public int x;
    public int y;
    public int ancho;
    public int alto;
    public int prioridad;

    public int distancia(int x1, int y1, int x2, int y2){

        return (int) Point2D.distance(x1, y1, x2, y2);
    }
}
