package FactoryMethod.FigurasTemplateMethod;

import Facade.Controles.Posicion;
import FactoryMethod.Figura;
import java.awt.*;

public class Linea extends Figura {

    public int pCx;
    public int pCy;
    public int pRx;
    public int pRy;

    public Linea(Posicion posClick, Posicion posReleased, Color c, int grosor){

        this.pCx=posClick.getX();
        this.pCy=posClick.getY();
        this.pRx=posReleased.getX();
        this.pRy=posReleased.getY();
        this.color = c;
        this.grosor = grosor;

    }
}
