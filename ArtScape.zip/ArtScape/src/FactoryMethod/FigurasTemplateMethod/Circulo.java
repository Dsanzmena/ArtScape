package FactoryMethod.FigurasTemplateMethod;

import Facade.Controles.Posicion;
import FactoryMethod.Figura;

import java.awt.*;

public class Circulo extends Figura {



    public Circulo(Posicion pC, Posicion pR , Color c, int grosor){

        if(pC.getX()>pR.getX()){
            x=pR.getX();
            if(pC.getY()>pR.getY()){
                y=pR.getY();

            }else{
                y=pC.getY();
            }
        }else{
            x=pC.getX();
            if(pC.getY()>pR.getY()){
                y=pR.getY();
            }else{
                y=pC.getY();
            }
        }

        this.grosor=grosor;
        this.color=c;
        this.ancho=distancia(pR.getX(),pR.getY(),pC.getX(),pC.getY());
        this.alto=ancho;

    }
}
