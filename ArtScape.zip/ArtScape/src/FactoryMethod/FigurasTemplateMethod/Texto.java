package FactoryMethod.FigurasTemplateMethod;

import Facade.Controles.Posicion;
import FactoryMethod.Figura;

import java.awt.*;

public class Texto extends Figura {

    public char[] texto;
    public boolean textoTerminado;
    private boolean barra=false;
    private int ultElem;
    public String fuente;

    public Texto(Posicion posClick, Color c, int grosor, String fuente){

        this.textoTerminado=false;
        this.texto = new char[100];
        this.ultElem=0;
        this.texto[ultElem]='_';
        this.x=posClick.getX();
        this.y=posClick.getY();
        this.color=c;
        this.grosor=grosor;
        this.fuente = fuente;
    }

    public void terminarTexto(){
        if(barra){
            texto[ultElem]=' ';
        }
        this.textoTerminado=true;
    }
    public void añadirCaracter(char c){
        texto[ultElem]=c;
        ultElem++;

        if(barra){
            texto[ultElem]=' ';
            barra=false;
        }else{
            texto[ultElem]='_';
            barra=true;
        }

    }
    public void eliminarCaracter(){

        if(ultElem!=0){

            texto[ultElem]=' ';
            ultElem--;
            texto[ultElem]=' ';

            if(barra){
                texto[ultElem]=' ';
                barra=false;
            }else{
                texto[ultElem]='_';
                barra=true;
            }
        }

    }
    public void actualizar(){

        if(barra){
            texto[ultElem]=' ';
            barra=false;
        }else{
            texto[ultElem]='_';
            barra=true;
        }
    }

}
