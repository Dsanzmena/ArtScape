package FactoryMethod.FigurasTemplateMethod;

import Facade.Controles.Posicion;
import FactoryMethod.Figura;

import java.awt.*;
import java.util.ArrayList;

public class Goma extends Figura {

    public ArrayList<Posicion> puntos;
    public ArrayList<Linea> lineas;
    private Posicion p1= new Posicion();
    private Posicion p2= new Posicion();

    public Goma(Color c, int grosor){

        this.puntos = new ArrayList<Posicion>();
        this.lineas = new ArrayList<Linea>();
        this.color = c;
        this.grosor = grosor;
    }

    public void añadirPuntos(Posicion posMov){
        puntos.add(posMov);
    }

}
