package FactoryMethod.FigurasTemplateMethod;

import Facade.Controles.Posicion;
import FactoryMethod.Figura;

import java.awt.*;

public class Cuadrado extends Figura {

    public Cuadrado(Posicion pC, Posicion pR, Color c, int grosor){

        if(pC.getX()>pR.getX()){
            x=pR.getX();
            if(pC.getY()>pR.getY()){
                y=pR.getY();

            }else{
                y=pC.getY();
            }
        }else{
            x=pC.getX();
            if(pC.getY()>pR.getY()){
                y=pR.getY();
            }else{
                y=pC.getY();
            }
        }


        this.grosor = grosor;
        this.color = c;
        this.ancho = distancia(pR.getX(),0,pC.getX(),0);
        this.alto = ancho;
        System.out.println("x: "+x+ " y: "+y+ " ancho "+ancho +" alto "+alto);
    }
}
