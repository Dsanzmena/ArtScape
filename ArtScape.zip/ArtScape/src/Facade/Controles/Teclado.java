package Facade.Controles;

import Logica.Ensamblador;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Teclado implements KeyListener{

    private Ensamblador ensamblador;
    public Teclado(Ensamblador ensamblador){
        this.ensamblador = ensamblador;
    }

    public void keyPressed(KeyEvent e) {
        ensamblador.teclaPulsada(e.getKeyCode(), e.getKeyChar());
    }

    public void keyReleased(KeyEvent e) {
        //System.out.println("tecla soltada "+e.getKeyChar());
    }

    public void keyTyped(KeyEvent e) {
        //System.out.println("tecla tecleada "+e.getKeyChar());






    }
}
