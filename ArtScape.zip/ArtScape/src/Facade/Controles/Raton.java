package Facade.Controles;

import Logica.Ensamblador;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class Raton extends MouseAdapter implements MouseMotionListener {

    public static Posicion posClick;
    public static Posicion posReleased;
    public static Posicion posRaton;

    private Ensamblador ensamblador;

    public boolean clickIzq;
    public boolean clickDrc;
    private boolean released;


    public Raton(Ensamblador ensamblador){

        this.ensamblador = ensamblador;
        this.posClick = new Posicion();
        this.posReleased = new Posicion();
        this.posRaton = new Posicion();
        this.released= false;
    }


    @Override
    public void mouseClicked(MouseEvent e) {

        if(e.getButton()==1){
            clickIzq=true;
            released=false;
        }else if(e.getButton()==3){
            clickDrc=true;
        }

        posClick.setPosicion(e.getX()-8, e.getY()-55);



    }


    @Override
    public void mousePressed(MouseEvent e) {

        if(e.getButton()==1){
            clickIzq=true;
            released=false;
            posClick.setPosicion(e.getX()-8, e.getY()-55);
        }
        else if(e.getButton()==3){
            clickDrc=true;
        }

        clickDrc=false;
        clickIzq=false;


        ensamblador.clikeado(posClick, posReleased);
    }

    @Override
    public void mouseReleased(MouseEvent e) {

        if(e.getButton()==1){
            clickIzq=false;
            released= true;
            posReleased.setPosicion(e.getX()-8, e.getY()-55);

        }
        else if(e.getButton()==3){
            clickDrc=false;
        }
        ensamblador.released(posClick,posReleased);

    }


    @Override
    public void mouseEntered(MouseEvent me) {
        //posicion= ("X = " + me.getX() + " Y = " + me.getY());
    }

    @Override
    public void mouseExited(MouseEvent me) {
        //posicion= "fuera de pantalla";

    }

    @Override
    public void mouseMoved(MouseEvent e){

        posRaton.setPosicion(e.getX()-8, e.getY()-55);

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        posRaton.setPosicion(e.getX()-8, e.getY()-55);
        ensamblador.dragged(posRaton);

    }

    public boolean isReleased(){
        return released;
    }
    public Posicion getReleased(){
        return posReleased;
    }
    public Posicion getClicked(){
        return posClick;
    }
    public Posicion getMoved(){
        return posRaton;
    }

}
