package Facade.Controles;

public class Posicion {

    private int posx;
    private int posy;

    public Posicion(int x, int y){

        this.posx = x;
        this.posy = y;
    }

    public Posicion(){
        this.posx = 0;
        this.posy = 0;
    }

    public void setPosicion(int x, int y){
        this.posx = x;
        this.posy = y;
    }

    public int getY(){
        return posy;
    }

    public int getX(){
        return posx;
    }

    @Override
    public String toString(){
        return "Pos x: "+this.posx+" Pos y: "+this.posy;
    }
}
