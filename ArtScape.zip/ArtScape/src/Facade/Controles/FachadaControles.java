package Facade.Controles;

import Logica.Ensamblador;

public class FachadaControles {

    private Ensamblador ensamblador;
    private Raton raton;
    private Teclado teclado;

    public FachadaControles(Ensamblador ensamblador){
        this.ensamblador =ensamblador;

        this.raton = new Raton(ensamblador);
        this.teclado = new Teclado(ensamblador);

    }

    public Raton getRaton(){
        return this.raton;
    }

    public Teclado getTeclado(){
        return this.teclado;
    }



}
