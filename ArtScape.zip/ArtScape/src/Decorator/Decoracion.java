package Decorator;

import java.awt.*;

public interface Decoracion {

    public abstract void setTamaño(int alto, int ancho);
    public abstract void setColorFondo(Color c);
    public abstract void setColorFuente(Color c);
    public abstract void setModo(String modo);

}
