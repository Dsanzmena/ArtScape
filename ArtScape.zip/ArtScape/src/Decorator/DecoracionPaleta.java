package Decorator;

import Singleton.Configuracion;
import javax.swing.*;
import java.awt.*;

public class DecoracionPaleta extends Decorador{

    private String posicionPaleta;

    public DecoracionPaleta(Decoracion d){
        super(d);

        Configuracion.ANCHO_PALETA = 400;
        Configuracion.ALTO_PALETA = 900;
        Configuracion.COLOR_FONDO = new JFrame().getBackground();
        Configuracion.COLOR_FUENTE = Color.BLACK;
        Configuracion.POSICION_PALETA = "IZQUIERDA";
    }

    public void setPosicionPaleta(String posicion){

        Configuracion.ANCHO_PALETA = 400;
        Configuracion.ALTO_PALETA = 900;
        Configuracion.POSICION_PALETA = posicion;
    }

    public void setTamaño(int alto, int ancho){
        Configuracion.ANCHO_PALETA = ancho;
        Configuracion.ALTO_PALETA = alto;
    }









}
