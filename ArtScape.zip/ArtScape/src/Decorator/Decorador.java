package Decorator;
import java.awt.*;

public abstract class Decorador implements Decoracion {

    private Decoracion decoracionGeneral;

    public Decorador(Decoracion decoracion){
        this.decoracionGeneral = decoracion;
    }

    @Override
    public  void setModo(String modo){
        this.decoracionGeneral.setModo(modo);
    }
    @Override
    public void setColorFondo(Color c){
        this.decoracionGeneral.setColorFondo(c);
    }
    @Override
    public void setColorFuente(Color c){
        this.decoracionGeneral.setColorFuente(c);
    }

    @Override
    public abstract void setTamaño(int alto, int ancho);

    public abstract void setPosicionPaleta(String posicion);









}
