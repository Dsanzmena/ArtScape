package Decorator;

import Singleton.Configuracion;
import java.awt.*;

public class DecoracionLienzo extends Decorador {

    public DecoracionLienzo(Decoracion d) {
        super(d);

        Configuracion.ANCHO_LIENZO = 1350;
        Configuracion.ALTO_LIENZO = 900;
        Configuracion.COLOR_FUENTE = Color.BLACK;
    }

    public void setTamaño(int alto, int ancho){
        Configuracion.ANCHO_LIENZO = ancho;
        Configuracion.ALTO_LIENZO = alto;
    }

    @Override
    public void setPosicionPaleta(String posicion){
        //Este método solo se implementa en DecoracionPaleta
    }








}
