package Main;

import Estate.Usuario;
import VentanasUsuario.VentanaLogIn;

import java.io.*;
import java.util.ArrayList;

public class ArtScape {


    public static void guardarDatos(ArrayList<Usuario> usuarios,String nombreFichero){

        try {
            ObjectOutputStream ficheroSalida = new ObjectOutputStream(new FileOutputStream(nombreFichero));
            ficheroSalida.writeObject(usuarios);
            ficheroSalida.flush();
            ficheroSalida.close();


        } catch (FileNotFoundException fnfe) {
            System.out.println("Error escritura: El fichero no existe. " + fnfe.toString());
        } catch (IOException ioe) {
            System.out.println("Error escritura: Fallo en la escritura en el fichero. " + ioe.toString());
        }
    }

    public static ArrayList<Usuario> recuperarDatos(String fichero){

        ArrayList<Usuario> datosRecuperados = new ArrayList<Usuario>();
        try{
            ObjectInputStream ficheroEntrada;
            ficheroEntrada = new ObjectInputStream(new FileInputStream(fichero));
            datosRecuperados= (ArrayList<Usuario>) ficheroEntrada.readObject();
            ficheroEntrada.close();

        }catch (FileNotFoundException fnfe){
            System.out.println("Error lectura: Fichero no existe" + fnfe.toString());
        }catch (IOException ioe){
            System.out.println("Error en la lectura del fichero" + ioe.toString());
        } catch (ClassNotFoundException ex) {
            System.out.println("Error lectura:" +  ex.toString());
        }

        return datosRecuperados;
    }


    public static void main(String args[]) {

        String fichero="ficheroUsuarios";
        ArrayList<Usuario> usuarios = recuperarDatos(fichero);

        if(usuarios.equals(null)) {//SI LOS DATOS NO HAN SIDO INICIALIZADOS
            usuarios = new ArrayList<Usuario>();

        }

        VentanaLogIn ventana = new VentanaLogIn();
        guardarDatos(usuarios,fichero);

    }
}
