package Observer;

import VentanasDibujo.Lienzo;
import VentanasDibujo.Paleta;
import Logica.Ensamblador;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class Observer implements PropertyChangeListener {

    private Paleta sujetoPaleta;
    private Lienzo sujetoLienzo;

    private Ensamblador ensamblador;

    public Observer(String nombre, Ensamblador ensamblador) {

        this.ensamblador = ensamblador;
        this.sujetoLienzo = ensamblador.getLienzo();
        this.sujetoLienzo.getPanelLienzo().añadirObserver(this);
        this.sujetoPaleta =  ensamblador.getPaleta();
        this.sujetoPaleta.getPanelPaleta().añadirObserver(this);

    }


    @Override
    public void propertyChange(PropertyChangeEvent evt) {

        String propiedad = evt.getPropertyName();

        if(propiedad.equals("HERRAMIENTA")){
            int nHerramienta = (int) evt.getNewValue();
            ensamblador.setHerramienta(nHerramienta);


        }else if(propiedad.equals("BOTONMENU")){
            String boton = (String) evt.getNewValue();
            ensamblador.botonSeleccionado(boton,"");

        }




    }
}
