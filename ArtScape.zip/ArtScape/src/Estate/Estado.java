package Estate;

import java.awt.*;

public interface Estado  {

    public void aumentarEstadistica(int indiceEstadistica);
    public void añadirColor(Color c);

}
