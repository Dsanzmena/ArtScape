package Estate;

import java.awt.*;
import java.io.Serializable;

public class EstadoNormal implements Estado, Serializable {

    public EstadoNormal(){

    }

    public void actualizarEstado(){

    }
    public void aumentarEstadistica(int indiceEstadistica){

    }
    public void añadirColor(Color c){

    }
}
