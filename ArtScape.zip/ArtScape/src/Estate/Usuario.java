package Estate;

import java.io.Serializable;

public class Usuario implements Serializable {


    private String nombre;
    private String clave;
    private Estado estado;


    public Usuario(String nombre, String clave, String estado) {

        this.nombre = nombre;
        this.clave = clave;

        if(estado.equals("NORMAL")){
            this.estado = new EstadoNormal();
        }else{
            this.estado = new EstadoPremium();
        }

    }

    //Si el usuario tiene una cuenta normal le ascendemos a cuenta premium.

    public void ascenderEstado(){

        if(this.estado instanceof EstadoNormal){
            this.estado = new EstadoPremium();
        }

    }

    public Estado getEstado(){
        return this.estado;
    }
    public String getNombre(){
        return this.nombre;
    }
    public String getClave(){
        return this.clave;
    }




}
