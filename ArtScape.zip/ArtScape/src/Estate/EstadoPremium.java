package Estate;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;

public class EstadoPremium implements Estado, Serializable {

    public int numeroFiguras[];
    public ArrayList<Color> coloresUsados;
    public int nVecesAtras;
    public int nVecesAvanzar;
    public int nVecesSeleccionColor;

    //Estadisticas
    /*
       FIGURAS:
       numeroFiguras[0]= Lapiz
       numeroFiguras[1]= Texto
       numeroFiguras[2]= Linea
       numeroFiguras[3]= Rectangulo
       numeroFiguras[4]= Cuadrado
       numeroFiguras[5]= Circulo
       numeroFiguras[6]= Elipse
     */

    public EstadoPremium(){

        this.numeroFiguras = new int[7];
        this.coloresUsados = new ArrayList<Color>();
        this.nVecesAtras = 0;
        this.nVecesAvanzar = 0;
        this.nVecesSeleccionColor = 0;
    }

    public void aumentarEstadistica(int indiceEstadistica){
        this.numeroFiguras[indiceEstadistica] = numeroFiguras[indiceEstadistica] +1;
    }

    public void añadirColor(Color c){
        if(!coloresUsados.contains(c)){
            coloresUsados.add(c);
        }
    }

    public void aumentarCambiosDibujo(String operacion){

        if(operacion.equals("ATRAS")){
            nVecesAtras++;
        }else if(operacion.equals("AVANZAR")){
            nVecesAvanzar++;
        }else if(operacion.equals("SELECCION")){
            nVecesSeleccionColor++;
        }
    }




}
