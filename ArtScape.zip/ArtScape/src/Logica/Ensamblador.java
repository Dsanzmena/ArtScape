package Logica;

//Packages
import Facade.Controles.*;
import VentanasDibujo.Lienzo;
import VentanasDibujo.Paleta;
import Decorator.DecoracionLienzo;
import Decorator.DecoracionPaleta;
import Decorator.Decorador;
import FactoryMethod.Figura;
import FactoryMethod.FigurasTemplateMethod.DibujoLibre;
import FactoryMethod.FigurasTemplateMethod.Goma;
import FactoryMethod.FigurasTemplateMethod.Linea;
import FactoryMethod.FigurasTemplateMethod.Texto;
import Observer.Observer;
import Singleton.Configuracion;
import Estate.Usuario;
import VentanasUsuario.VentanaEstadisticas;

//Librerias
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;


public class Ensamblador {

    //CONFIGURACION Y DECORACION
    private Configuracion configuracionGeneral;
    private Decorador decoradorLienzo;
    private Decorador decoradorPaleta;

    //VENTANAS PALETA Y LIENZO
    private Lienzo lienzo;
    private Paleta paleta;
    private Observer observador;
    private Figura ultimaFigura;

    //CONTROLES
    private FachadaControles fachadaControles;
    private Teclado teclado;

    //FACTORY METHOD FIGURAS
    public String herramienta;

    //JFILECHOOSER
    private JFileChooser fileChooser;

    //USUARIOS
    private Usuario usuarioActual;

    public Ensamblador(Usuario usuario){

        this.configuracionGeneral = new Configuracion();
        this.decoradorLienzo = new DecoracionLienzo(configuracionGeneral);
        this.decoradorPaleta = new DecoracionPaleta(configuracionGeneral);

        this.fachadaControles = new FachadaControles(this);

        this.lienzo = new Lienzo(decoradorLienzo, herramienta, fachadaControles);
        lienzo.setFocusTraversalKeysEnabled(false); //Nos permite capturar y manejar las teclas pulsadas Tab y Shift del teclado
        this.paleta = new Paleta(decoradorPaleta, herramienta);
        this.observador = new Observer("ObservadorEventosVentana", this);
        this.fileChooser = new JFileChooser();

        this.usuarioActual = usuario;

        setHerramienta(1);
        inicializaListeners();
        actualizarVentanas();
    }


    
    private void inicializaListeners(){

        //MANTIENE A LAS VENTANAS SIEMPRE JUNTAS
        Actualizador actualizador = new Actualizador(lienzo, paleta, configuracionGeneral);
        actualizador.start();

        //LISTENER QUE CIERRA LA PALETA AL CERRAR EL LIENZO
        lienzo.addWindowListener(new WindowAdapter(){

            public void windowClosing(WindowEvent we){
                paleta.dispose();
                actualizador.parar();
            }

        });

        //LIENZO ESCUCHA AL RATON Y TECLADO
        lienzo.addKeyListener(fachadaControles.getTeclado());
        lienzo.addMouseMotionListener(fachadaControles.getRaton());
        lienzo.addMouseListener(fachadaControles.getRaton());

        //PALETA ESCUCHA AL RATON Y TECLADO
        paleta.addKeyListener(fachadaControles.getTeclado());
        paleta.addMouseMotionListener(fachadaControles.getRaton());
        paleta.addMouseListener(fachadaControles.getRaton());
    }
    private void actualizarVentanas(){

        lienzo.setSize(Configuracion.ANCHO_LIENZO, Configuracion.ALTO_LIENZO);

        int x =0 ,y= 0;
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Point centerPoint = ge.getCenterPoint();

        if(Configuracion.POSICION_PALETA.equals("IZQUIERDA")){

            x = centerPoint.x -Configuracion.ANCHO_LIENZO/3;
            y = centerPoint.y -Configuracion.ALTO_PALETA/2;

            lienzo.setLocation(x,y);

        }else if(Configuracion.POSICION_PALETA.equals("DERECHA")){

            x = centerPoint.x -Configuracion.ANCHO_LIENZO+ Configuracion.ANCHO_PALETA + 100;
            y = centerPoint.y -Configuracion.ALTO_PALETA/2;

            lienzo.setLocation(x,y);
        }

        lienzo.setVisible(true);
        paleta.setSize(Configuracion.ANCHO_PALETA, Configuracion.ALTO_PALETA);
        paleta.setColorPanel(Configuracion.COLOR_FONDO);
        paleta.setVisible(true);
    }

    public void botonSeleccionado(String boton, String formato){

        switch (boton){

            case "Abrir":
                lienzo.añadirImagen(abrirImagen());
                break;
            case "Guardar como...":
                guardarImagen(lienzo.guardarImagen());
                break;
            case "Modo oscuro":
                configuracionGeneral.setModo("OSCURO");
                actualizarVentanas();
                break;
            case "Modo claro":
                configuracionGeneral.setModo("CLARO");
                actualizarVentanas();
                break;
            case "Lateral izquierdo":
                decoradorPaleta.setPosicionPaleta("IZQUIERDA");
                actualizarVentanas();
                break;
            case "Lateral derecho":
                decoradorPaleta.setPosicionPaleta("DERECHA");
                actualizarVentanas();
                break;

            case "Mi perfil":
                VentanaEstadisticas ventana = new VentanaEstadisticas(usuarioActual);
                lienzo.dispose();
                paleta.dispose();
                break;

            case "Cerrar sesión":
                lienzo.dispose();
                paleta.dispose();
                break;


        }
    }

    //OPERACIONES
    private BufferedImage abrirImagen(){

        BufferedImage imagen = null;
        int operacion = fileChooser.showOpenDialog(lienzo);

        if(operacion == JFileChooser.APPROVE_OPTION){
            File archivo = fileChooser.getSelectedFile();

            try{
                imagen = ImageIO.read(archivo);

            }catch (Exception e){
                System.out.println("Error en la conversion del archivo a imagen");
            }
        }else if(operacion == JFileChooser.ERROR_OPTION){
            System.out.println("Ha ocurrido un error al abrir la imagen");
        }
        return imagen;
    }
    private void guardarImagen(BufferedImage img){

        int operacion = fileChooser.showSaveDialog(lienzo);

        if(operacion == JFileChooser.APPROVE_OPTION) {
            File fichero = fileChooser.getSelectedFile();

            try {
                ImageIO.write(img, "jpeg", fichero);
            } catch (Exception e) {
                System.out.println("Ha ocurrido un error al guardar la imagen");
            }

        }else if(operacion == JFileChooser.ERROR_OPTION){
            System.out.println("Ha ocurrido un error al abrir la imagen");
        }
    }
    private void terminarTexto(){
        try{
            Texto t = (Texto) ultimaFigura;
            t.terminarTexto();
        }catch (Exception e){

        }
    }

    //DIBUJAR MEDIANTE EL RATON
    public void released(Posicion click, Posicion released){

        int grosor = 1;

        switch(herramienta){

            case "LINEA":
                terminarTexto(); //Terminamos el texto en el caso en el que el usuario no lo haya terminado
                grosor = paleta.getPanelPaleta().getGrosor();

                if(grosor!=0){
                    lienzo.añadirDibujo(click, released,grosor,"");
                }

                //Actualizamos las estadisticas del usuario premium
                usuarioActual.getEstado().aumentarEstadistica(2);
                usuarioActual.getEstado().añadirColor(lienzo.getColorSeleccionado());
                break;

            case "RECTANGULO":
                terminarTexto(); //Terminamos el texto en el caso en el que el usuario no lo haya terminado
                grosor = paleta.getPanelPaleta().getGrosor();
                if(grosor!=0){
                    lienzo.añadirDibujo(click, released,grosor,"");
                }

                //Actualizamos las estadisticas del usuario premium
                usuarioActual.getEstado().aumentarEstadistica(3);
                usuarioActual.getEstado().añadirColor(lienzo.getColorSeleccionado());
                break;

            case "CUADRADO":
                terminarTexto(); //Terminamos el texto en el caso en el que el usuario no lo haya terminado
                grosor = paleta.getPanelPaleta().getGrosor();
                if(grosor!=0){
                    lienzo.añadirDibujo(click, released,grosor,"");
                }

                //Actualizamos las estadisticas del usuario premium
                usuarioActual.getEstado().aumentarEstadistica(4);
                usuarioActual.getEstado().añadirColor(lienzo.getColorSeleccionado());
                break;

            case "CIRCULO":
                terminarTexto(); //Terminamos el texto en el caso en el que el usuario no lo haya terminado
                grosor = paleta.getPanelPaleta().getGrosor();
                if(grosor!=0){
                    lienzo.añadirDibujo(click, released,grosor,"");
                }

                //Actualizamos las estadisticas del usuario premium
                usuarioActual.getEstado().aumentarEstadistica(5);
                usuarioActual.getEstado().añadirColor(lienzo.getColorSeleccionado());
                break;

            case "ELIPSE":
                terminarTexto(); //Terminamos el texto en el caso en el que el usuario no lo haya terminado
                grosor = paleta.getPanelPaleta().getGrosor();
                if(grosor!=0){
                    lienzo.añadirDibujo(click, released,grosor,"");
                }

                //Actualizamos las estadisticas del usuario premium
                usuarioActual.getEstado().aumentarEstadistica(6);
                usuarioActual.getEstado().añadirColor(lienzo.getColorSeleccionado());

            case "SELECCION":
                terminarTexto();
                break;
        }
    }
    public void clikeado(Posicion click, Posicion released){

        terminarTexto(); //Terminamos el texto en el caso en el que el usuario no lo haya terminado
        int grosor = paleta.getPanelPaleta().getGrosor();
        int tamañoTexto = paleta.getPanelPaleta().getTamañoTexto();
        String fuente = paleta.getPanelPaleta().getFuente();

        if(grosor!=0){
            switch(herramienta){

                case "DIBUJO LIBRE":
                    DibujoLibre dibujo= (DibujoLibre) lienzo.añadirDibujo(click, released, grosor,"");
                    ultimaFigura = dibujo;

                    //Actualizamos las estadisticas del usuario premium
                    usuarioActual.getEstado().aumentarEstadistica(0);
                    usuarioActual.getEstado().añadirColor(lienzo.getColorSeleccionado());
                    break;

                case "GOMA":
                    Goma goma = (Goma) lienzo.añadirDibujo(click, released, grosor,"");
                    ultimaFigura = goma;
                    break;

                case "TEXTO":
                    Texto texto = (Texto) lienzo.añadirDibujo(click, released, tamañoTexto,fuente);
                    ultimaFigura = texto;

                    //Actualizamos las estadisticas del usuario premium
                    usuarioActual.getEstado().añadirColor(lienzo.getColorSeleccionado());
                    usuarioActual.getEstado().aumentarEstadistica(1);
                    break;

                case "CUENTAGOTAS":
                    lienzo.obtenerColorCuentagotas(click);
                    break;

                case "CUBO":
                    lienzo.pintarCubo(click);
                    break;
            }
        }

    }
    public void dragged(Posicion posMov){

        switch(herramienta) {

            case "DIBUJO LIBRE" :
                DibujoLibre dibujo = (DibujoLibre) ultimaFigura;
                if(dibujo!=null){
                    dibujo.puntos.add(new Posicion(posMov.getX(), posMov.getY()));

                    if(dibujo.puntos.size()>1){
                        Posicion p=dibujo.puntos.get(dibujo.puntos.size()-1);
                        Posicion p2=dibujo.puntos.get(dibujo.puntos.size()-2);
                        Linea linea = lienzo.añadirLineas(p,p2, dibujo.color, dibujo.grosor);
                        dibujo.lineas.add(linea);
                    }
                }
                break;

            case "GOMA":
                Goma goma = (Goma) ultimaFigura;
                if(goma!=null){
                    goma.puntos.add(new Posicion(posMov.getX(), posMov.getY()));

                    if(goma.puntos.size()>1){
                        Posicion p=goma.puntos.get(goma.puntos.size()-1);
                        Posicion p2=goma.puntos.get(goma.puntos.size()-2);
                        Linea linea = lienzo.añadirLineas(p,p2, goma.color, goma.grosor);
                        goma.lineas.add(linea);
                    }
                }
                break;
        }
    }

    //DIBUJAR TEXTO MEDIANTE TECLADO
    public void teclaPulsada(int tecla, char caracter){

        if(herramienta.equals("TEXTO")){
            Texto texto = (Texto) ultimaFigura;

            switch(tecla){

                case KeyEvent.VK_ESCAPE:
                    texto.terminarTexto();
                    break;
                case KeyEvent.VK_BACK_SPACE:
                    texto.eliminarCaracter();
                    break;
                case KeyEvent.VK_TAB:
                    for(int i=0 ;i<4; i++) {
                        texto.añadirCaracter(' ');
                    }
                    break;
                case KeyEvent.VK_CAPS_LOCK: //Activa CAPS pero no escribe ningun caracter
                    break;
                case KeyEvent.VK_SHIFT: //Activa SHIFT pero no escriber ningun caracter
                    break;

                default: //Escriber cualquier caracter que no se haya detectado en los anteriores case
                    texto.añadirCaracter(caracter);
                    break;
            }
        }

    }

    //GETTERS Y SETTERS
    public Lienzo getLienzo(){
        return this.lienzo;
    }
    public Paleta getPaleta(){
        return this.paleta;
    }
    public void setHerramienta(int numeroHerramienta){

        switch(numeroHerramienta){

            case 1:
                herramienta = "DIBUJO LIBRE";
                break;
            case 2:
                herramienta = "GOMA";
                break;
            case 3:
                herramienta = "TEXTO";
                break;
            case 4:
                herramienta = "LINEA";
                break;
            case 5:
                herramienta = "RECTANGULO";
                break;
            case 6:
                herramienta = "CUADRADO";
                break;
            case 7:
                herramienta = "CIRCULO";
                break;
            case 8:
                herramienta = "ELIPSE";
                break;
            case 9:
                herramienta = "CUENTAGOTAS";
                Color c = lienzo.obtenerColorCuentagotas(Raton.posClick);
                paleta.setColorDibujo(c);
                break;
            case 10:
                herramienta = "CUBO";
                break;

            case 11:
                herramienta = "COLOR";
                terminarTexto();
                Color color = JColorChooser.showDialog(lienzo, "Elige un color", Color.black);
                paleta.setColorDibujo(color);
                lienzo.setColorDibujo(color);
                break;
            case 12:
                herramienta = "RETROCESO";
                terminarTexto();
                lienzo.cogerImagenAnterior();
                break;
            case 13:
                herramienta = "AVANZAR";
                terminarTexto();
                lienzo.cogerImagenPosterior();
                break;

        }

        lienzo.setHerramienta(herramienta);
    }




}
