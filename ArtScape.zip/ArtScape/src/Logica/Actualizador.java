package Logica;


import VentanasDibujo.Lienzo;
import VentanasDibujo.Paleta;
import Singleton.Configuracion;

public class Actualizador extends Thread{

    private Lienzo lienzo;
    private Paleta paleta;
    private Configuracion c;
    private boolean condicion;

    public Actualizador(Lienzo lienzo, Paleta paleta, Configuracion c){

        this.lienzo = lienzo;
        this.paleta = paleta;
        this.c = c;
        this.condicion = true;


    }

    public void run(){

        String posicion;
        while(condicion){

            posicion = Configuracion.POSICION_PALETA;
            lienzo.getContentPane().repaint();

            //COLOCA LA PALETA A LA IZQUIERDA DEL LIENZO
            if(posicion.equals("IZQUIERDA")){
                this.paleta.setLocation(lienzo.getX()-paleta.getWidth(),lienzo.getY());
            }
            //COLOCA LA PALETA A LA DERECHA DEL LIENZO
            else if(posicion.equals("DERECHA")){
                this.paleta.setLocation(lienzo.getX()+lienzo.getWidth(),lienzo.getY());

            }
            //COLOCA LA PALETA EN LA PARTE SUPERIOR DEL LIENZO
            else if(posicion.equals("SUPERIOR")){
                this.paleta.setLocation(lienzo.getX(),lienzo.getY() - paleta.getHeight());
            }


        }
    }

    public void parar(){
        this.condicion = false;
    }

}
