package VentanasUsuario;

import Estate.Usuario;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

import static Main.ArtScape.guardarDatos;
import static Main.ArtScape.recuperarDatos;

public class VentanaRegistro extends JFrame {

    private JButton botonRegistrarse;
    private JButton botonCancelar;
    private JTextField nombre;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JPasswordField clave;
    private JPasswordField claveRepetida;
    private JLabel imagenLabel;
    private JRadioButton botonMostrar;

    private ButtonGroup grupoBotonesColor;
    private JRadioButton radioUserNormal;
    private JRadioButton radioUserPremium;



    public VentanaRegistro(){

        iniciarComponentes();

        ImageIcon imagenIcono=new ImageIcon("src\\recursos\\iconArtScape.png");
        setIconImage(imagenIcono.getImage());

        ImageIcon imagen=new ImageIcon("src\\recursos\\ArtScapeLogo.png");
        Icon icono =new ImageIcon(imagen.getImage().getScaledInstance(imagenLabel.getWidth(),imagenLabel.getHeight(), Image.SCALE_DEFAULT));
        imagenLabel.setIcon(icono);

        this.getContentPane().setBackground(Color.WHITE);
        botonMostrar.setBackground(Color.WHITE);

        this.setTitle("LogIn");
        this.setSize(560,500);


    }

    private void iniciarComponentes(){

        botonRegistrarse = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        grupoBotonesColor = new ButtonGroup();
        nombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        clave = new javax.swing.JPasswordField();
        imagenLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        claveRepetida = new javax.swing.JPasswordField();
        radioUserNormal = new javax.swing.JRadioButton();
        radioUserPremium = new javax.swing.JRadioButton();
        grupoBotonesColor.add(radioUserNormal);
        grupoBotonesColor.add(radioUserPremium);
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        botonMostrar = new javax.swing.JRadioButton();
        radioUserPremium.setBackground(Color.white);
        radioUserNormal.setBackground(Color.white);
        radioUserNormal.setSelected(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        botonRegistrarse.setText("Registrarse");
        botonRegistrarse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarseActionPerformed(evt);
            }
        });

        botonCancelar.setText("Salir");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });


        jLabel1.setText("Nombre usuario:");

        jLabel2.setText("Contraseña:");

        clave.setToolTipText("");

        jLabel3.setText("Repite contraseña:");

        claveRepetida.setToolTipText("");

        radioUserNormal.setText("Usuario normal");

        radioUserPremium.setText(" Usuario premium");

        jLabel4.setText("Añade opciones de personalización");

        jLabel5.setText("Visualización de estadísticas");

        jLabel6.setText("Funcionaldades por defecto, sin añadidos");

        botonMostrar.setText("Mostrar contraseña");
        botonMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMostrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(imagenLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 50, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(botonMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel1)
                                                .addContainerGap())
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                .addComponent(jLabel2)
                                                                .addComponent(jLabel3)
                                                                .addComponent(clave, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                                                                .addComponent(claveRepetida))
                                                        .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(24, 24, 24)
                                                                .addComponent(botonRegistrarse, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(radioUserPremium, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGroup(layout.createSequentialGroup()
                                                                                .addGap(21, 21, 21)
                                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                                        .addComponent(jLabel4)
                                                                                        .addComponent(jLabel6)
                                                                                        .addComponent(jLabel5)))
                                                                        .addComponent(radioUserNormal, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGap(38, 38, 38))
                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                                .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(86, 86, 86))))))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(imagenLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel1)
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(clave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(11, 11, 11)
                                                .addComponent(jLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(claveRepetida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(radioUserNormal)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel6)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(radioUserPremium)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel4)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel5)))
                                .addGap(18, 18, 18)
                                .addComponent(botonMostrar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(botonCancelar)
                                        .addComponent(botonRegistrarse))
                                .addGap(29, 29, 29))
        );

        pack();
    }

    private void botonRegistrarseActionPerformed(java.awt.event.ActionEvent evt) {

        String nombreUser = nombre.getText().toLowerCase();
        String claveUser = String.valueOf(clave.getPassword());
        String claveUserRepe = String.valueOf(claveRepetida.getPassword());

        ArrayList<Usuario> usuarios = recuperarDatos("ficheroUsuarios");

        //Comprobamos si el nombre introducido ya está en uso por otro usuario
        boolean nombreCogido = false;
        for(Usuario user:usuarios){

            String nombre = user.getNombre();

            if(nombre.equals(nombreUser)){
                nombreCogido = true;
                break;
            }
        }

        //Si el nombre no esta cogido registramos al usuario
        if(!nombreCogido){
            if(claveUser.equals(claveUserRepe)){

                String estadoPremium = "NORMAL";

                if(radioUserPremium.isSelected()){
                    estadoPremium = "PREMIUM";
                }
                Usuario user = new Usuario(nombreUser,claveUser,estadoPremium);
                usuarios.add(user);

                guardarDatos(usuarios, "ficheroUsuarios");

                dispose();

                VentanaLogIn ventana = new VentanaLogIn();

            }
        }else{
            JOptionPane.showMessageDialog(this, "El nombre que has introducido ya esta en uso por otro usuario", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            nombre.setText("");
            clave.setText("");
            claveRepetida.setText("");
        }


    }

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {
        dispose();
        VentanaLogIn ventana = new VentanaLogIn();
    }


    private void botonMostrarActionPerformed(java.awt.event.ActionEvent evt) {
        if(botonMostrar.isSelected()){
            clave.setEchoChar((char)0);
            claveRepetida.setEchoChar((char)0);
        }else{
            clave.setEchoChar('*');
            claveRepetida.setEchoChar('*');
        }
    }
}
