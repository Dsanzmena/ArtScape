package VentanasUsuario;

import Logica.Ensamblador;
import Estate.Usuario;


import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

import static Main.ArtScape.recuperarDatos;

public class VentanaLogIn extends JFrame {

    private JLabel imagenLabel;
    private JTextField nombre;
    private JPasswordField clave;
    private JTextPane texto;
    private JRadioButton botonMostrar;

    private JLabel jLabel1;
    private JLabel jLabel2;
    private JScrollPane jScrollPane1;
    private JButton botonIniciarSesion;
    private JButton botonRegistrarse;
    private JButton botonCancelar;


    public VentanaLogIn()  {

        iniciarComponentes();

        ImageIcon imagenIcono=new ImageIcon("src\\recursos\\iconArtScape.png");
        setIconImage(imagenIcono.getImage());

        ImageIcon imagen=new ImageIcon("src\\recursos\\ArtScapeLogo.png");
        Icon icono =new ImageIcon(imagen.getImage().getScaledInstance(imagenLabel.getWidth(),imagenLabel.getHeight(),Image.SCALE_DEFAULT));
        imagenLabel.setIcon(icono);
        this.getContentPane().setBackground(Color.WHITE);
        botonMostrar.setBackground(Color.WHITE);

        this.setTitle("LogIn");
        this.setSize(560,500);

        this.texto.setText("Bienvenido/a a ArtScape. \n\nArtScape es una aplicación de edición y creación de imágenes  hecha para artistas. \n\nInicia sesión para comenzar o registrate si no cuentas con una cuenta.");

        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }


    private void iniciarComponentes(){

        botonIniciarSesion = new javax.swing.JButton();
        botonRegistrarse = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        nombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        clave = new javax.swing.JPasswordField();
        jScrollPane1 = new javax.swing.JScrollPane();
        texto = new javax.swing.JTextPane();
        imagenLabel = new javax.swing.JLabel();
        botonMostrar = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        botonIniciarSesion.setText("Iniciar sesión");
        botonIniciarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonIniciarSesionActionPerformed(evt);
            }
        });

        botonRegistrarse.setText("Registrarse");
        botonRegistrarse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarseActionPerformed(evt);
            }
        });

        botonCancelar.setText("Salir");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });


        jLabel1.setText("Nombre usuario:");

        jLabel2.setText("Contraseña:");

        clave.setToolTipText("");

        texto.setEnabled(false);
        jScrollPane1.setViewportView(texto);

        botonMostrar.setText("Mostrar contraseña");
        botonMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMostrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(imagenLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addGap(13, 13, 13)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(botonRegistrarse, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(46, 46, 46)
                                                                .addComponent(botonIniciarSesion, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
                                                                .addGap(38, 38, 38)
                                                                .addComponent(botonCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                                .addComponent(clave)
                                                                                .addComponent(jLabel2)
                                                                                .addComponent(nombre)
                                                                                .addComponent(botonMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                        .addComponent(jLabel1))
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(19, 19, 19)))
                                .addGap(46, 46, 46))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(imagenLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(clave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(botonMostrar))
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(botonIniciarSesion)
                                        .addComponent(botonCancelar)
                                        .addComponent(botonRegistrarse))
                                .addGap(38, 38, 38))
        );

        jScrollPane1.setViewportBorder(null);
        jScrollPane1.setBorder(null);

        pack();
    }


    private void botonIniciarSesionActionPerformed(java.awt.event.ActionEvent evt) {

        String nombreUsu = nombre.getText().toLowerCase();
        String claveUsu = String.valueOf(clave.getPassword());

        ArrayList<Usuario> usuarios = recuperarDatos("ficheroUsuarios");

        if (nombreUsu.equals("") || (claveUsu.equals(""))) {//SI LOS CAMPOS NO HAN SIDO RELLENADOS
            JOptionPane.showMessageDialog(this, "Alguno de los campos no han sido correctamente rellenados", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } else {//SI NO ES NINGUNA DE LAS ANTERIORES ENTONCES COMPRUEBA SI EL CORREO ES CORRECTO

            boolean loginCorrecto = false;
            for (Usuario user : usuarios) {//BUSCA ENTRE TODOS LOS CLIENTES

                if (user.getNombre().equals(nombreUsu)) {//SI EL CORREO COINCIDE

                    if (user.getClave().equals(claveUsu)) {//SI LA CLAVE TAMBIEN COINCIDE
                        loginCorrecto = true;
                        dispose();
                        Usuario usuarioActual = user;//PONEMOS COMO USUARIO ACTUAL AL QUE SE ACABA DE VALIDAR

                        Ensamblador e = new Ensamblador(usuarioActual);

                    }
                }

            }
            if (!loginCorrecto) {//SI NO COINCIDE CLAVE O CORREO MUESTRA MENSAJE Y PIDE QUE INTRODUCZA DE NUEVO IDENTIFICACION
                JOptionPane.showMessageDialog(this, "La clave o contraseña no es correcta ", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
                nombre.setText("");
                clave.setText("");

            }
        }
    }

    private void botonRegistrarseActionPerformed(java.awt.event.ActionEvent evt) {
        dispose();
        VentanaRegistro ventanaRegistrar = new VentanaRegistro();
        ventanaRegistrar.setLocationRelativeTo(null);
        ventanaRegistrar.setVisible(true);
    }

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {
        dispose();

    }


    private void botonMostrarActionPerformed(java.awt.event.ActionEvent evt) {
        if(botonMostrar.isSelected()){
            clave.setEchoChar((char)0);
        }else{
            clave.setEchoChar('*');
        }
    }

}
