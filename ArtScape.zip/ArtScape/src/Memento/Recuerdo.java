package Memento;

import java.awt.image.BufferedImage;

public class Recuerdo {

    private BufferedImage imagen;
    public int prioridad;

    public Recuerdo(BufferedImage imagen,int prioridad){
        this.imagen =imagen;
        this.prioridad = prioridad;
    }

    public BufferedImage getImagen(){
        return imagen;
    }

}
