package Memento;

import java.util.ArrayList;

public class ColectorImagenesConserje {

    public ArrayList<Recuerdo> recuerdos = new ArrayList<>();

    public void guardarRecuerdo(Recuerdo recuerdo){
        recuerdos.add(recuerdo);
    }

    public Recuerdo getRecuerdo(int prioridad) {

        if(prioridad>=recuerdos.size()){
            return null;
        }else{
            return recuerdos.get(prioridad);
        }


    }
}
