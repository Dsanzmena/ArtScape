package Memento;

import java.awt.image.BufferedImage;

public class Originador {

    private BufferedImage imagenActual;


    public BufferedImage getImagenActual(){
        return imagenActual;
    }

    public void setImagenActual(BufferedImage imagen){
        this.imagenActual = imagen;
    }

    public void setRecuerdo(Recuerdo recuerdo){
        imagenActual = recuerdo.getImagen();
    }

    public Recuerdo crearRecuerdo(BufferedImage imagen,int prioridad){
        Recuerdo r = new Recuerdo(imagen,prioridad);
        setRecuerdo(r);
        return r;

    }


}
